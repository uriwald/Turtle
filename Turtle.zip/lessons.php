<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<?php
session_start();
$m = new Mongo();
// select a database
$db = $m->turtleTestDb;

// select a collection (analogous to a relational database's table)
$lessons = $db->lessons;

$locale = "en_US";
if (isset($_GET['l']))
    $locale = $_GET['l'];

//If we are in existing lesson we will enter editing mode 
if (isset($_GET['lesson'])) {
    $theObjId = new MongoId($_GET['lesson']);
    $cursor = $lessons->findOne(array("_id" => $theObjId));
    $cursortitle = $cursor["title"];


    $localSteps = $cursor["steps"];
    $lessonSteps = $cursor["steps"];

    foreach ($lessonSteps as $key => $value) {
        if (isset($lessonSteps[$key]['locale_' . $_GET['l']])) {
            $localSteps[$key] = $lessonSteps[$key]['locale_' . $_GET['l']];
        }
    }

    echo $cursortitle;
    foreach ($cursortitle as $key => $value) {
        if (isset($_GET['l'])) {
            if ($key == 'locale_' . $_GET['l']) {
                // $cursor["title"] = $cursortitle[$key];
                $cursor["title"] = $value;
            }
        } else { //Case no Language set
            $cursor["title"] = $cursortitle[$key];
        }
    }
}
?>

<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
        <script  type="text/javascript" src="ckeditor/ckeditor.js"></script>
        <script  type="text/javascript" src="ckeditor/adapters/jquery.js"></script>
        <link rel='stylesheet' href='./files/lessons.css' type='text/css' media='all'/>
        <script type="text/javascript">
            function bu()
            {
                
                $( 'textarea' ).ckeditor();
                //$( 'textarea' ).ckeditor( function() { /* callback code */ }, { skin : 'kama' , toolbar : [ [ 'Source', '-', 'Bold', 'Italic', 'Underline', 'Strike','-','Link', '-', 'MyButton' ] ] });


            }
            
            $(document).ready(function() {
                bu();
                $('#btnAdd').click(function() {       
                    var num     = $('.clonedInput').length; // how many "duplicatable" input fields we currently have
                    var newNum  = new Number(num + 1);      // the numeric ID of the new input field being added
                    $('#numOfObjects').attr('value',newNum);

                    // create the new element via clone(), and manipulate it's ID using newNum value
                    var newElem = $('#input' + num).clone().attr('id', 'input' + newNum);
                    // manipulate the name/id values of the input inside the new element
                    newElem.children(':first').attr('id', 'title' + newNum).attr('name', 'title' + newNum).attr('value','');
                    newElem.children(':first').next().attr('id', 'explanation' + newNum).attr('name', 'explanation' + newNum).attr('value','');
                    // newElem.children(':first').next().next() is the cke element 
                    newElem.children(':first').next().next().remove();
                    newElem.children(':first').next().next().next().attr('id', 'action' + newNum).attr('name', 'action' + newNum).attr('value','');
                    newElem.children(':first').next().next().next().next().attr('id', 'solution' + newNum).attr('name', 'solution' + newNum).attr('value','');
                    newElem.children(':first').next().next().next().next().next().attr('id', 'hint' + newNum).attr('name', 'hint' + newNum).attr('value','');

 
                    // insert the new element after the last "duplicatable" input field
                    $('#input' + num).after(newElem);
 
                    // enable the "remove" button
                    $('#btnDel').attr('disabled','');
 
                    bu();
                    // business rule: you can only add 5 names
                    if (newNum == 10)
                        $('#btnAdd').attr('disabled','disabled');
                });
                
                $('#btnSubmit').click(function() {
                    var num     = $('.clonedInput').length;
                    $('#btnSubmit').attr('value',num);
                 
                });
                  
 
                $('#btnDel').click(function() {
                    var num = $('.clonedInput').length; // how many "duplicatable" input fields we currently have
                    $('#input' + num).remove();     // remove the last element
                    $('#numOfObjects').attr('value',num - 1);
                    // enable the "add" button
                    $('#btnAdd').attr('disabled','');
             
                    // if only one element remains, disable the "remove" button
                    if (num-1 == 1)
                        $('#btnDel').attr('disabled','disabled');
                });
 
                $('#btnDel').attr('disabled','disabled');
            });
        </script>
    </head>
    <body>

        <form id="myForm" action="processEditedRecord.php" method="post">
            Lesson Title : <input type="text" name="lessonTitle"  id="lessonTitle" value="<?php
if (isset($cursor["title"]))
    echo $cursor["title"];
else {
    echo "";
}
?>"/>
            Object ID: <input type="text" name="ObjId" display="none" id="lessonObjectId" value="<?php
if (isset($cursor["_id"]))
    echo $cursor["_id"];
else {
    echo "";
}
?>"/>
            <?php
            $i = 1; //Set default value to 1 in case there are no steps
            if (isset($cursor["steps"]) && count($cursor["steps"]) > 0) {
                $i = 0;
                foreach ($localSteps as $step) {
                    $i++;
                    ?>
                    <div id="input<?php echo $i ?>" style="margin-bottom:4px;" class="clonedInput">
                                      <?php echo "Step Number " . $i . ",\n" ?>
                        Title:               <input type="text" class="lessonElement" name="title<?php echo $i ?>" id="<?php echo "title" . $i ?>" value="<?php echo $step["title"] ?>"/>
                        Explanation :
                        <?php
                        $stepex = $step["explanation"];
                        echo "<textarea type='text' name='explanation$i' id='explanation$i' >$stepex </textarea>"
                        ?>



        <?php
        $action = $step["action"];
        $solution = $step["solution"];
        $hint = $step["hint"];
        $baseInputText = "%%a: <input type='text' style='width:500px;' class='lessonElement' name='%%b' id='%%b' value='%%c' /> ";
        $toReplace = array("%%a", "%%b", "%%c");

        $replaceWithAction = array("Action ", "action$i", $action);
        $replaceWithSolution = array("Solution ", "solution$i", $solution);
        $replaceWithHint = array("Hint ", "hint$i", $hint);

        $elementAction = str_replace($toReplace, $replaceWithAction, $baseInputText);
        $elementSolution = str_replace($toReplace, $replaceWithSolution, $baseInputText);
        $elementHint = str_replace($toReplace, $replaceWithHint, $baseInputText);
        echo $elementAction;
        //   echo "Action: <input type='text' class='lessonElement' name='action$i' id='action$i' value='$action' />";
        echo $elementSolution;
        echo $elementHint;
        ?>

                    </div>
                        <?php
                    } //End of for each loop
                    ?>
                <div>
                    <input type="button" id="btnAdd" value="Add lesson step" />
                    <input type="button" id="btnDel" value="remove lesoon step" disabled="" />
                </div>
    <?php
} //end of if
else {
    ?>
                <div id="input1" style="margin-bottom:4px;" class="clonedInput">

                    Title:         <input type="text" name="title1" id="title1"  />
                    Explanation :  <textarea type="text"  name="explanation1" id="explanation1">
                    </textarea> 



                    Action:                 <input type="text" name="action1" id="action1" />
                    Solution:            <input type="text" name="solution1" id="solution1" />
                    Hint:                       <input type="text" name="hint1"  id="hint1" />

                </div>

                <div>
                    <input type="button" id="btnAdd" value="add Add lesson step" />
                    <input type="button" id="btnDel" value="remove lesson step" disabled="" />
                </div>
    <?php
} //end of else
?>
            <input type="submit" id="btnSubmit" name="formSubmit" value="Save" />
            <input type="submit" id="btnDelete" name="formDelete" value="Delete Lesson" />
            <input type="text" name="language" display="none" value=<?php echo $locale ?> />
            <input type="text" name="numOfObjects" display="none" id="numOfObjects" value=<?php echo $i ?> />

        </form>
    </body>
</html>
