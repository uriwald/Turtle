var lessons = {
    
    {"steps":{"1":{"title":"Logo's turtle",
                        "action":"Write down the command forward 50",
                        "solution":"forward 50",
                        "hint":"no hint"},
,"title":{"locale_he_IL":"\u05d4\u05db\u05e8 \u05d0\u05ea \u05d4\u05e6\u05d1","locale_en_US":"Getting to know the turtle"}

}
    };