<?php

    $n = 3;
    printf(ngettext("%d comment", "%d comments", $n), $n);
?>
